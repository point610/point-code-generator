# ACM 模板代码

> 作者：point

提供 ACM 模式的 Java 示例代码